from Tkinter import *

root = Tk()

root.title('Canvas')
canvas = Canvas(root, width =400, height=400)
 
canvas.pack(expand=YES, fill=BOTH)                

canvas.create_oval(10, 10, 200, 200, width=2, fill='blue')

canvas.create_polygon(205,105,285,125,166,177,210,199,205,105, fill='white')

canvas.pack()
root.mainloop()

