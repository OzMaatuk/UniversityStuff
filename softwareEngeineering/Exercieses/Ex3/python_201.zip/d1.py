from Tkinter import *

canvas = Canvas(width=300, height=300, bg='white')  
canvas.pack(expand=YES, fill=BOTH)                

canvas.create_oval(10, 10, 200, 200, width=2, fill='blue')

mainloop()
